package com.webservice.rest.exception;

public class DoctorNotFoundException  extends RuntimeException{

    public DoctorNotFoundException(String string) {
        super();
    }
}
