package com.webservice.rest.exception;

public class PatientNotFoundException  extends RuntimeException{
    public PatientNotFoundException(String string) {
        super();
    }
}
